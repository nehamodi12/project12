from django.apps import AppConfig


class Orders1Config(AppConfig):
    name = 'orders'
