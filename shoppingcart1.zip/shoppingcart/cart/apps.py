from django.apps import AppConfig


class Cart1Config(AppConfig):
    name = 'cart'
