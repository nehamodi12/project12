from django.apps import AppConfig


class Shop1Config(AppConfig):
    name = 'shop'
